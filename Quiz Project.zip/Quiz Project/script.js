// Category → Trivia API ID mapping
const categoryMap = {
    gk: 9,            // General Knowledge
    programming: 18,  // Computers
    science: 17,      // Science
    sports: 21,       // Sports
    history: 23,      // History
    geography: 22    // Geography
};

let questions = [];
let currentQuestionIndex = 0;
let score = 0;

const categorySection = document.getElementById("category-section");
const quizSection = document.getElementById("quiz-section");
const resultSection = document.getElementById("result-section");

const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const scoreEl = document.getElementById("score");
const loadingEl = document.getElementById("loading");

const correctSound = document.getElementById("correctSound");
const wrongSound = document.getElementById("wrongSound");

async function startQuiz(category) {

  const categoryId = categoryMap[category];

    score = 0;
    currentQuestionIndex = 0;
    scoreEl.textContent = "Score: 0";

    categorySection.classList.add("d-none");
    quizSection.classList.remove("d-none");

    loadingEl.classList.remove("d-none");
    questionEl.textContent = "";
    optionsEl.innerHTML = "";

    const url = `https://opentdb.com/api.php?amount=5&category=${categoryId}&type=multiple`;

    const res = await fetch(url);
    const data = await res.json();

    questions = data.results;

    loadingEl.classList.add("d-none");
    loadQuestion();
}

function loadQuestion() {
  optionsEl.innerHTML = "";

  const q = questions[currentQuestionIndex];
  questionEl.innerHTML = q.question;

  const answers = [...q.incorrect_answers, q.correct_answer];
  answers.sort(() => Math.random() - 0.5);

  answers.forEach(answer => {
    const btn = document.createElement("button");
    btn.className = "btn btn-outline-light";
    btn.innerHTML = answer; // keep innerHTML for special characters
    btn.onclick = () => checkAnswer(answer);
    optionsEl.appendChild(btn);
  });
}


function decodeHtml(str) {
  const txt = document.createElement("textarea");
  txt.innerHTML = str;
  return txt.value;
}

function checkAnswer(selectedAnswer) {
  const correct = decodeHtml(questions[currentQuestionIndex].correct_answer);
  const selected = decodeHtml(selectedAnswer);

  if (selected === correct) {
    score++;
    if (correctSound) correctSound.play().catch(() => {});
  } else {
    if (wrongSound) wrongSound.play().catch(() => {});
  }

  scoreEl.textContent = "Score: " + score;

  currentQuestionIndex++;

  if (currentQuestionIndex < questions.length) {
    loadQuestion();
  } else {
    endQuiz();
  }
}


function endQuiz() {

    quizSection.classList.add("d-none");
    resultSection.classList.remove("d-none");

    // Final score
    document.getElementById("final-score").textContent =
        `Your Score: ${score} / ${questions.length}`;

    // ✅ Result badge logic
    const badge = document.getElementById("resultBadge");

    if (!badge) return; // safety check

    if (score === questions.length) {
    badge.textContent = "🏆 Perfect Score!";
    badge.className = "text-success";

    launchConfetti(); // 🎉 CONFETTI
}

    else if (score >= questions.length / 2) {
        badge.textContent = "🎯 Good Job!";
        badge.className = "text-warning";
    }
    else {
        badge.textContent = "📘 Keep Practicing!";
        badge.className = "text-danger";
    }
}
function launchConfetti() {
    const duration = 3000;
    const end = Date.now() + duration;

    (function frame() {
        confetti({
            particleCount: 5,
            spread: 70,
            origin: { x: Math.random(), y: Math.random() - 0.2 }
        });

        if (Date.now() < end) {
            requestAnimationFrame(frame);
        }
    })();
}
